# -*- coding: utf-8 -*-
# __init__.py
"""rendseq, to analyze end-enriched RNA sequencing data."""

# version of the rendseq package:
__version__ = "0.1.5"
